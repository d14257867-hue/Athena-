(() => {
  const $ = s => document.querySelector(s);
  const storeKey = 'athena-pwa-data-v1';
  const defaults = {notes:[],tasks:[],learning:[],settings:{voiceMode:'Natural / Warm',speechRate:1,confirm:true}};
  let data = load();
  let lastReply = "Hello, Boss. I'm Athena. I can manage notes, tasks and learning goals in this local version.";
  let recognition = null;

  function load(){
    try { return {...defaults,...JSON.parse(localStorage.getItem(storeKey)||'{}')}; }
    catch { return structuredClone(defaults); }
  }
  function save(){ localStorage.setItem(storeKey, JSON.stringify(data)); }
  function id(){ return (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()+Math.random())); }
  function toast(message){ const el=$('#toast'); el.textContent=message; el.classList.add('show'); setTimeout(()=>el.classList.remove('show'),2300); }
  function escapeText(s){ return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  // Navigation
  function go(page){
    document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===`page-${page}`));
    document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.page===page));
    window.scrollTo({top:0,behavior:'smooth'});
  }
  document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>go(b.dataset.page)));
  document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.goto)));

  // Chat: transparent local helper, not a pretend remote model
  function addMessage(who,text){
    const el=document.createElement('div'); el.className=`msg ${who==='You'?'user-msg':'athena-msg'}`;
    const b=document.createElement('b'); b.textContent=who;
    const p=document.createElement('p'); p.textContent=text;
    el.append(b,p); $('#chat-log').append(el); $('#chat-log').scrollTop=$('#chat-log').scrollHeight;
  }
  function answer(input){
    const q=input.trim(); const low=q.toLowerCase();
    if(/^(hi|hello|hey)\b/.test(low)) return "Hello, Boss. What would you like to work on?";
    if(/\b(time|date|today)\b/.test(low)) return `Today is ${new Date().toLocaleDateString(undefined,{weekday:'long',year:'numeric',month:'long',day:'numeric'})}.`;
    if(/\b(note|remember|write down|take down)\b/.test(low)){
      const content=q.replace(/^(please\s+)?(note|remember|write down|take down)\s*/i,'').trim();
      if(content){ data.notes.unshift({id:id(),title:'Quick note',body:content,created:new Date().toISOString()}); save(); renderNotes(); return "I've saved that as a quick note on this phone, Boss."; }
      return "Tell me what you'd like me to save. You can also open Notes to add a title.";
    }
    if(/\b(task|todo|to-do|remind me)\b/.test(low)){
      const content=q.replace(/^(please\s+)?(add a task|task|todo|to-do|remind me to)\s*/i,'').trim();
      if(content){data.tasks.unshift({id:id(),text:content,done:false,created:new Date().toISOString()});save();renderTasks();return "I've added that to your task list. This version does not send background notifications yet.";}
      return "What task should I add?";
    }
    if(/\bnotes?\b/.test(low)) return `You currently have ${data.notes.length} saved note(s). Open the Notes tab to search and manage them.`;
    if(/\btask(s)?\b/.test(low)) return `You have ${data.tasks.filter(t=>!t.done).length} open task(s). Open the Tasks tab to manage them.`;
    if(/\bhelp\b/.test(low)) return "I can save a note, add a task, tell you the date, and guide you around this app. For general reasoning, coding help and research, I still need a genuinely free AI model connection.";
    return "I can store that in a note or task, Boss. This build is offline-first and does not yet contain a connected AI model, so I won't pretend I can answer every question. Try 'note …', 'task …' or open the Learning Lab.";
  }
  $('#chat-form').addEventListener('submit',e=>{
    e.preventDefault(); const value=$('#chat-input').value.trim(); if(!value)return;
    addMessage('You',value); lastReply=answer(value); addMessage('Athena',lastReply); $('#chat-input').value='';
  });

  // Notes
  function renderNotes(){
    const query=$('#note-search').value.toLowerCase();
    const list=$('#notes-list'); list.replaceChildren();
    const filtered=data.notes.filter(n=>(n.title+' '+n.body).toLowerCase().includes(query));
    $('#note-count').textContent=`${data.notes.length} saved`;
    if(!filtered.length){list.innerHTML='<div class="empty">No matching notes yet.</div>';return;}
    filtered.forEach(n=>{
      const el=document.createElement('article');el.className='item';
      const main=document.createElement('div');main.className='item-main';
      const h=document.createElement('h3');h.textContent=n.title;
      const p=document.createElement('p');p.textContent=n.body;
      const small=document.createElement('small');small.className='tiny';small.textContent=new Date(n.created).toLocaleString();
      main.append(h,p,small);
      const actions=document.createElement('div');actions.className='item-actions';
      const del=document.createElement('button');del.className='danger';del.textContent='Delete';del.addEventListener('click',()=>{data.notes=data.notes.filter(x=>x.id!==n.id);save();renderNotes();});
      actions.append(del);el.append(main,actions);list.append(el);
    });
  }
  $('#note-form').addEventListener('submit',e=>{
    e.preventDefault();const title=$('#note-title').value.trim(),body=$('#note-body').value.trim();if(!title||!body)return;
    data.notes.unshift({id:id(),title,body,created:new Date().toISOString()});save();e.target.reset();renderNotes();toast('Note saved on this phone.');
  });
  $('#note-search').addEventListener('input',renderNotes);

  // Tasks
  function renderTasks(){
    const list=$('#tasks-list');list.replaceChildren();
    $('#task-count').textContent=`${data.tasks.filter(t=>!t.done).length} open`;
    if(!data.tasks.length){list.innerHTML='<div class="empty">No tasks yet. Add your first one above.</div>';return;}
    data.tasks.forEach(t=>{
      const el=document.createElement('article');el.className='item'+(t.done?' done':'');
      const main=document.createElement('div');main.className='item-main';
      const h=document.createElement('h3');h.textContent=t.text;main.append(h);
      const actions=document.createElement('div');actions.className='item-actions';
      const toggle=document.createElement('button');toggle.className='secondary';toggle.textContent=t.done?'Reopen':'Complete';toggle.addEventListener('click',()=>{t.done=!t.done;save();renderTasks();});
      const del=document.createElement('button');del.className='danger';del.textContent='Delete';del.addEventListener('click',()=>{data.tasks=data.tasks.filter(x=>x.id!==t.id);save();renderTasks();});
      actions.append(toggle,del);el.append(main,actions);list.append(el);
    });
  }
  $('#task-form').addEventListener('submit',e=>{e.preventDefault();const text=$('#task-input').value.trim();if(!text)return;data.tasks.unshift({id:id(),text,done:false,created:new Date().toISOString()});save();e.target.reset();renderTasks();toast('Task added.');});

  // Learning log
  function renderLearning(){
    const list=$('#learning-list');list.replaceChildren();
    if(!data.learning.length){list.innerHTML='<div class="empty">Your learning plan will appear here.</div>';return;}
    data.learning.forEach(item=>{
      const el=document.createElement('article');el.className='item';
      const main=document.createElement('div');main.className='item-main';
      const h=document.createElement('h3');h.textContent=item.subject;
      const p=document.createElement('p');p.textContent=item.goal;main.append(h,p);
      const actions=document.createElement('div');actions.className='item-actions';
      const del=document.createElement('button');del.className='danger';del.textContent='Remove';del.addEventListener('click',()=>{data.learning=data.learning.filter(x=>x.id!==item.id);save();renderLearning();});
      actions.append(del);el.append(main,actions);list.append(el);
    });
  }
  $('#learn-form').addEventListener('submit',e=>{e.preventDefault();const goal=$('#learn-goal').value.trim();if(!goal)return;data.learning.unshift({id:id(),subject:$('#learn-subject').value,goal,created:new Date().toISOString()});save();e.target.reset();renderLearning();toast('Learning goal saved.');});

  // Speech features
  function startSpeech(target){
    const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SpeechRecognition){$('#voice-status').textContent='Speech recognition is not available in this browser. Try a supported browser or your phone keyboard microphone.';toast('Speech input unavailable in this browser.');return;}
    if(recognition){try{recognition.stop()}catch{}}
    recognition=new SpeechRecognition();recognition.lang='en-ZA';recognition.interimResults=false;recognition.maxAlternatives=1;
    $('#voice-status').textContent='Listening… speak now.';
    recognition.onresult=e=>{const text=e.results[0][0].transcript;if(target==='note'){$('#note-body').value=($('#note-body').value+' '+text).trim();}else{$('#chat-input').value=text;}$('#voice-status').textContent='Voice captured.';};
    recognition.onerror=e=>{$('#voice-status').textContent=`Voice input error: ${e.error}. You can type instead.`;};
    recognition.onend=()=>{if($('#voice-status').textContent==='Listening… speak now.')$('#voice-status').textContent='Listening stopped.';};
    try{recognition.start()}catch{$('#voice-status').textContent='Could not start the microphone. Check browser permission.';}
  }
  $('#voice-input').addEventListener('click',()=>startSpeech('chat'));
  $('#dictate-note').addEventListener('click',()=>startSpeech('note'));
  $('#voice-stop').addEventListener('click',()=>{if(recognition)recognition.stop();$('#voice-status').textContent='Stopped.';});
  $('#voice-output').addEventListener('click',()=>{
    if($('#voice-mode').value==='Silent Text-Only'){toast('Silent Text-Only mode is selected.');return;}
    if(!('speechSynthesis'in window)){toast('Speech output is not supported here.');return;}
    speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(lastReply);u.rate=Number($('#speech-rate').value);u.lang='en-ZA';speechSynthesis.speak(u);
  });

  // Settings
  $('#voice-mode').value=data.settings.voiceMode||defaults.settings.voiceMode;
  $('#speech-rate').value=data.settings.speechRate||1;
  $('#rate-value').textContent=`${Number($('#speech-rate').value).toFixed(2)}×`;
  $('#confirm-actions').checked=data.settings.confirm!==false;
  $('#voice-mode').addEventListener('change',()=>{data.settings.voiceMode=$('#voice-mode').value;save();});
  $('#speech-rate').addEventListener('input',()=>$('#rate-value').textContent=`${Number($('#speech-rate').value).toFixed(2)}×`);
  $('#speech-rate').addEventListener('change',()=>{data.settings.speechRate=Number($('#speech-rate').value);save();});
  $('#confirm-actions').addEventListener('change',()=>{data.settings.confirm=$('#confirm-actions').checked;save();});

  // Portable JSON backup
  $('#export-data').addEventListener('click',()=>{
    const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
    const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='athena-backup.json';a.click();URL.revokeObjectURL(url);$('#backup-status').textContent='Backup exported. Keep it somewhere safe.';
  });
  $('#import-data').addEventListener('change',async e=>{
    const file=e.target.files[0];if(!file)return;
    try{const parsed=JSON.parse(await file.text());if(!parsed||!Array.isArray(parsed.notes)||!Array.isArray(parsed.tasks)||!Array.isArray(parsed.learning))throw new Error('Invalid backup');data={...defaults,...parsed};save();renderNotes();renderTasks();renderLearning();$('#backup-status').textContent='Backup imported.';toast('Backup restored.');}
    catch{$('#backup-status').textContent='Could not import this file. It may not be an Athena backup.';}
    e.target.value='';
  });
  $('#clear-data').addEventListener('click',()=>{
    if(!confirm('Erase all Athena notes, tasks, learning goals and settings from this browser? This cannot be undone unless you exported a backup.'))return;
    localStorage.removeItem(storeKey);data=structuredClone(defaults);renderNotes();renderTasks();renderLearning();$('#backup-status').textContent='Local data erased.';toast('Local data erased.');
  });

  // PWA install and offline service worker
  let installPrompt=null;
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;$('#install-btn').hidden=false;});
  $('#install-btn').addEventListener('click',async()=>{if(!installPrompt){toast('Use your browser menu and choose Add to Home screen.');return;}installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$('#install-btn').hidden=true;});
  if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
  $('#today-line').textContent=new Date().toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'});
  $('#offline-indicator').textContent=navigator.onLine?'● Offline-ready':'● Offline';
  window.addEventListener('online',()=>$('#offline-indicator').textContent='● Offline-ready');
  window.addEventListener('offline',()=>$('#offline-indicator').textContent='● Offline');
  renderNotes();renderTasks();renderLearning();
})();