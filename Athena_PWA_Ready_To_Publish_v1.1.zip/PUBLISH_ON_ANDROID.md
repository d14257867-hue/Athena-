# Publish Athena from your Android phone

Follow the numbered steps in `START_HERE.txt`. This project is designed to be hosted as a static HTTPS website and then added to your Android home screen.

## Files you should see after extracting
- `index.html` — app screen
- `app.js` — app behaviour
- `styles.css` — appearance
- `manifest.webmanifest` — installable-app details
- `sw.js` — offline cache
- `icon.svg` — app icon
- `README.md` and `ROADMAP.md` — technical notes and future plan

## Do not do these things
- Do not upload the ZIP file as the only file in the GitHub repository.
- Do not put private information or API keys in a public repository.
- Do not assume the current version is connected to Gemini. It is not.
- Do not delete the original Athena project or your separate master project document.

## Current capability boundary
This is a local-first PWA starter. It is not a native APK, not a full AI assistant, and not a replacement for Android system permissions. Speech features depend on browser/device support.
