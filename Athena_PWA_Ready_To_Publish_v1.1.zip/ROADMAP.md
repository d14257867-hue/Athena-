# Athena roadmap — zero-cost-first

## Stage 1 — included in this package
A local-first Android PWA with notes, tasks, learning goals, voice features where browser-supported, settings, backup and offline cache.

## Stage 2 — AI brain, only if truly free
Evaluate free model options and current limits before integration. Check South Africa availability, prompt retention, daily quotas, data use and whether a payment method is required. Keep the AI provider optional. The app must continue to work without it.

Never expose API keys in front-end code or a public repository. Do not activate billing.

## Stage 3 — selected app integrations
Connect only services the owner names. Prefer official Android intents or OAuth/API permission flows. Ask before write actions. Provide disconnect controls.

## Stage 4 — native Android application
A native Android app can investigate call-screening/default-dialer capabilities, notification access and background operation. These features need explicit system permission and careful testing. Do not promise that it can answer calls until the relevant Android role and device behaviour are verified.

## Stage 5 — Skills Lab
A restricted environment for coding exercises, tests and defensive security learning. No unrestricted shell access, no automatic installation, and no running unknown code on the phone. Use rollback and owner approval for changes.
