# Athena Android App — Free Local Edition

**Version 1.0 · Offline-first PWA · No paid services required for included features**

This is a functioning Progressive Web App starter intended for an Android phone. It is not a native APK and it is not connected to an online AI model.

## Included working features
- Mobile-first installable web-app structure.
- Notes: create, search, dictate where supported, delete.
- Tasks: add, complete/reopen, delete.
- Learning Lab: record and remove learning goals.
- Local assistant commands: `note ...`, `task ...`, help, date, and simple counts.
- Speech output using the browser/device speech engine where available.
- Speech input using browser Web Speech API where supported; otherwise use Android keyboard microphone.
- Local preferences for speaking style and speed.
- JSON backup export and import.
- Offline caching after first successful load over HTTPS.

## What is deliberately NOT claimed
- It does not answer incoming calls.
- It does not have full phone access.
- It does not connect to an AI model or provide general-purpose AI reasoning yet.
- It does not execute arbitrary programs, install apps, change firewall settings, or scan the phone.
- It does not connect to Calendar, email, contacts, files or music services.
- It does not sync data to cloud storage.

## Zero-cost deployment
The app can be hosted as static files on GitHub Pages using a **public repository** on GitHub Free. GitHub Pages supports HTTPS. Because the repository is public, do not upload private notes, API keys, passwords or personal data into the repository.

Official references:
- GitHub Pages availability and public repository requirement: https://docs.github.com/en/pages/getting-started-with-github-pages
- GitHub Pages HTTPS: https://docs.github.com/en/pages/getting-started-with-github-pages/securing-your-github-pages-site-with-https

### Android installation
1. Extract this ZIP.
2. Create a public GitHub repository, for example `athena-app`.
3. Upload the files from this folder to the repository root using GitHub in your phone browser.
4. In repository Settings → Pages, publish from the `main` branch and root folder.
5. Wait for the GitHub Pages address to appear.
6. Open that HTTPS address in Chrome on Android.
7. Open Chrome's menu and choose **Add to Home screen** or **Install app**.
8. Open Athena from the new home-screen icon.
9. Test notes and tasks. Export a backup.

The PWA's service worker needs HTTPS or localhost. GitHub Pages provides HTTPS. The first visit needs internet to download the app; after the files are cached, the core interface can work offline.

## Data and privacy
App data is stored in the browser's local storage on this phone. It is not encrypted and is not synced. Browser storage can be erased by clearing site data, so export regular backups. Do not store secrets or highly sensitive information.

## Free AI connection — later stage
A remote AI API may offer a free quota, but free tiers can change, have daily limits, collect prompts, or require account registration. No provider has been embedded in this version. Never place an API key directly in a public website's JavaScript: anyone could extract it. A genuinely private AI integration needs a secure backend or a model running locally on capable hardware. Do not enable billing or add a payment method if the requirement is strictly zero spend.

## Native Android features — later stage
Answering calls, deeper notification access, background services, and controlled code execution require a native Android app and explicit Android permissions/roles. A PWA cannot safely or reliably provide those functions.
